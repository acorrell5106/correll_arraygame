
package correll_deliverer;

import org.newdawn.slick.state.*;

import java.io.IOException;

import java.util.ArrayList;

import java.util.Iterator;

import java.util.logging.Level;

import java.util.logging.Logger;

import org.newdawn.slick.Animation;
import org.newdawn.slick.Color;

import org.newdawn.slick.AppGameContainer;

import org.newdawn.slick.BasicGame;

import org.newdawn.slick.Font;

import org.newdawn.slick.GameContainer;

import org.newdawn.slick.Graphics;

import org.newdawn.slick.Image;

import org.newdawn.slick.Input;

import org.newdawn.slick.SlickException;

import org.newdawn.slick.SpriteSheet;

import org.newdawn.slick.TrueTypeFont;

import org.newdawn.slick.geom.Rectangle;

import org.newdawn.slick.geom.Shape;

import org.newdawn.slick.state.BasicGameState;

import org.newdawn.slick.state.StateBasedGame;
import org.newdawn.slick.state.transition.FadeInTransition;
import org.newdawn.slick.state.transition.FadeOutTransition;

import org.newdawn.slick.tiled.TiledMap;
import org.w3c.dom.css.Rect;

public class Deliverer extends BasicGameState {

        public Orb blue;
        public OrbRed red;
        public OrbYellow yellow;
        
            public static boolean blueb;
            public static boolean redb;
            public static boolean yellowb;

	public ArrayList<Item> stuff = new ArrayList();
        
        public ArrayList<Orb> orbz = new ArrayList();
        
        public ArrayList<OrbRed> orbzz = new ArrayList();
        
        public ArrayList<OrbYellow> orbzzz = new ArrayList();

	private boolean[][] hostiles;

	private static TiledMap grassMap;

	private static AppGameContainer app;

	private static Camera camera;
	
	public static int counter = 15000;

	private Animation sprite, up, down, left, right, wait;

	private static final int SIZE = 32;

	private static final int SCREEN_WIDTH = 800;

	private static final int SCREEN_HEIGHT = 750;

	public Deliverer(int xSize, int ySize) {

	}

	public void init(GameContainer gc, StateBasedGame sbg)

	throws SlickException {
		
		 gc.setTargetFrameRate(60);

		gc.setShowFPS(false);

		grassMap = new TiledMap("res/final.tmx");

		System.out.println("Tile map is this wide: " + grassMap.getWidth());

		camera = new Camera(gc, grassMap);

		SpriteSheet runningSS = new SpriteSheet(
				"res/protagonist.png",64, 64, 0);

		up = new Animation();

		up.setAutoUpdate(true);

		up.addFrame(runningSS.getSprite(0, 8), 330);

		up.addFrame(runningSS.getSprite(1, 8), 330);

		up.addFrame(runningSS.getSprite(2, 8), 330);

		up.addFrame(runningSS.getSprite(3, 8), 330);

		up.addFrame(runningSS.getSprite(4, 8), 330);

		up.addFrame(runningSS.getSprite(5, 8), 330);

		up.addFrame(runningSS.getSprite(6, 8), 330);

		up.addFrame(runningSS.getSprite(7, 8), 330);

		up.addFrame(runningSS.getSprite(8, 8), 330);

		down = new Animation();

		down.setAutoUpdate(false);

		down.addFrame(runningSS.getSprite(0, 10), 330);

		down.addFrame(runningSS.getSprite(1, 10), 330);

		down.addFrame(runningSS.getSprite(2, 10), 330);

		down.addFrame(runningSS.getSprite(3, 10), 330);

		down.addFrame(runningSS.getSprite(4, 10), 330);

		down.addFrame(runningSS.getSprite(5, 10), 330);

		down.addFrame(runningSS.getSprite(6, 10), 330);

		down.addFrame(runningSS.getSprite(7, 10), 330);

		down.addFrame(runningSS.getSprite(8, 10), 330);

		left = new Animation();

		left.setAutoUpdate(false);

		left.addFrame(runningSS.getSprite(0, 9), 330);

		left.addFrame(runningSS.getSprite(1, 9), 330);

		left.addFrame(runningSS.getSprite(2, 9), 330);

		left.addFrame(runningSS.getSprite(3, 9), 330);

		left.addFrame(runningSS.getSprite(4, 9), 330);

		left.addFrame(runningSS.getSprite(5, 9), 330);

		left.addFrame(runningSS.getSprite(6, 9), 330);

		left.addFrame(runningSS.getSprite(7, 9), 330);

		left.addFrame(runningSS.getSprite(8, 9), 330);

		right = new Animation();

		right.setAutoUpdate(false);

		right.addFrame(runningSS.getSprite(0, 11), 330);

		right.addFrame(runningSS.getSprite(1, 11), 330);

		right.addFrame(runningSS.getSprite(2, 11), 330);

		right.addFrame(runningSS.getSprite(3, 11), 330);

		right.addFrame(runningSS.getSprite(4, 11), 330);

		right.addFrame(runningSS.getSprite(5, 11), 330);

		right.addFrame(runningSS.getSprite(6, 11), 330);

		right.addFrame(runningSS.getSprite(7, 11), 330);

		right.addFrame(runningSS.getSprite(8, 11), 330);

		wait = new Animation();

		wait.setAutoUpdate(true);

		wait.addFrame(runningSS.getSprite(0, 14), 733);

		wait.addFrame(runningSS.getSprite(1, 14), 733);

		wait.addFrame(runningSS.getSprite(2, 14), 733);

		wait.addFrame(runningSS.getSprite(3, 14), 733);

		sprite = wait;

		Blocked.blocked = new boolean[grassMap.getWidth()][grassMap.getHeight()];

		System.out.println("The grassmap is " + grassMap.getWidth() + "by "
				+ grassMap.getHeight());

		for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {

			for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {

				int tileID = grassMap.getTileId(xAxis, yAxis, 0);

				String value = grassMap.getTileProperty(tileID,

				"blocked", "false");

				if ("true".equals(value)) {

					System.out.println("The tile at x " + xAxis + " andy axis "
							+ yAxis + " is blocked.");

					Blocked.blocked[xAxis][yAxis] = true;

				}

			}

		}

		System.out.println("Array length" + Blocked.blocked[0].length);

		hostiles = new boolean[grassMap.getWidth()][grassMap.getHeight()];

		for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {
			for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {
				int xBlock = (int) xAxis;
				int yBlock = (int) yAxis;
				if (!Blocked.blocked[xBlock][yBlock]) {
					if (yBlock % 7 == 0 && xBlock % 15 == 0 ) {

					}
				}
			}
		}
		
		for (int xAxis = 0; xAxis < grassMap.getWidth(); xAxis++) {
			for (int yAxis = 0; yAxis < grassMap.getHeight(); yAxis++) {
				int xBlock = (int) xAxis;
				int yBlock = (int) yAxis;
				if (!Blocked.blocked[xBlock][yBlock]) {
					if (xBlock % 9 == 0	&& yBlock % 25 == 0) {

					}
				}
			}
		}

                blue = new Orb(705, 190);
                red = new OrbRed(60, 700);
                yellow = new OrbYellow(180, 480);
         
                orbz.add(blue);
                orbzz.add(red);
                orbzzz.add(yellow);
		
	}

	public void render(GameContainer gc, StateBasedGame sbg, Graphics g)

	throws SlickException {

		camera.centerOn((int) Player.x, (int) Player.y);

		camera.drawMap();

		camera.translateGraphics();

		sprite.draw((int) Player.x, (int) Player.y);
		
                //coordinates
                
		//g.drawString("x: " + (int)Player.x + "y: " +(int)Player.y , Player.x, Player.y - 10);
		                
		g.drawString("Time Passed: " +counter/1000, camera.cameraX +10,camera.cameraY );
                
                for (Orb o : orbz) {
			if (o.isvisible) {
				o.currentImage.draw(o.x, o.y);
				//g.draw(o.hitbox);

			}
		}
                
                for (OrbRed o : orbzz) {
			if (o.isvisible) {
				o.currentImage.draw(o.x, o.y);
				//g.draw(o.hitbox);

			}
		}
                                
                for (OrbYellow o : orbzzz) {
			if (o.isvisible) {
				o.currentImage.draw(o.x, o.y);
				//g.draw(o.hitbox);

			}
		}
                
	}

	public void update(GameContainer gc, StateBasedGame sbg, int delta)

	throws SlickException {
		
		counter -= delta;

		Input input = gc.getInput();

		float fdelta = delta * Player.speed;

		Player.setpdelta(fdelta);

		double rightlimit = (grassMap.getWidth() * SIZE) - (SIZE * 0.75);

		float projectedright = Player.x + fdelta + SIZE;

		boolean cangoright = projectedright < rightlimit;

		if (input.isKeyDown(Input.KEY_UP)) {

			sprite = up;

			float fdsc = (float) (fdelta - (SIZE * .15));

			if (!(isBlocked(Player.x, Player.y - fdelta) || isBlocked((float) (Player.x + SIZE + 1.5), Player.y + fdelta))) {
				sprite.update(delta);

				Player.y -= fdelta;

			}

		} else if (input.isKeyDown(Input.KEY_DOWN)) {

			sprite = down;

			if (!isBlocked(Player.x, Player.y + SIZE + fdelta)

			|| !isBlocked(Player.x + SIZE - 1, Player.y + SIZE + fdelta)) {

				sprite.update(delta);

				Player.y += fdelta;

			}

		} else if (input.isKeyDown(Input.KEY_LEFT)) {

			sprite = left;

			if ((Player.getPlayersX() > 5) && (!(isBlocked(Player.x - fdelta, Player.y) || isBlocked(Player.x

			- fdelta, Player.y + SIZE - 1)) || isBlocked(Player.x - SIZE/2 - fdelta, Player.y
							+ SIZE - 1))) {

				sprite.update(delta);

				Player.x -= fdelta;

			}

		} else if (input.isKeyDown(Input.KEY_RIGHT)) {

			sprite = right;

			if (cangoright
					&& (!(isBlocked(Player.x + SIZE + fdelta,

					Player.y) || isBlocked(Player.x + SIZE + fdelta, Player.y
							+ SIZE - 1)))) {

				sprite.update(delta);

				Player.x += fdelta;

			}

		}

		Player.rect.setLocation(Player.getPlayershitboxX(),
				Player.getPlayershitboxY()+50);

                
                for (Orb o : orbz) {

			if (Player.rect.intersects(o.hitbox)) {
				if (o.isvisible) {

                                        blueb = true;
					o.isvisible = false;
				}

			}
		}
                                
                for (OrbRed o : orbzz) {

			if (Player.rect.intersects(o.hitbox)) {
				if (o.isvisible) {

                                        redb = true;
					o.isvisible = false;
				}

			}
		}
                                
                for (OrbYellow o : orbzzz) {

			if (Player.rect.intersects(o.hitbox)) {
				if (o.isvisible) {

					yellowb = true;
					o.isvisible = false;
				}

			}
		}
		 
		if(counter <= 0){
			makevisible();
			sbg.enterState(2, new FadeOutTransition(Color.white), new FadeInTransition(Color.white));
		}
                
                if(blueb && redb && yellowb){
                    sbg.enterState(3, new FadeOutTransition(Color.white), new FadeInTransition(Color.white));
                } 

	}

	public int getID() {

		return 1;

	}

	public void makevisible(){
		
		for (Item i : stuff) {
			
			i.isvisible = true;}
		}
	
	private boolean isBlocked(float tx, float ty) {

		int xBlock = (int) tx / SIZE;

		int yBlock = (int) ty / SIZE;

		return Blocked.blocked[xBlock][yBlock];

	}

}
