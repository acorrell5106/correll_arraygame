

package correll_deliverer;

import org.newdawn.slick.Animation;
import org.newdawn.slick.geom.Rectangle;
import org.newdawn.slick.geom.Shape;

public class Player {

	public static float x = 96f;

	public static float y = 228f;

	public static int health = 100000;
	
	public static float speed = .4f;

	static float hitboxX = x + 8f;

	static float hitboxY = y + 100;

	private static int startX, startY, width = 30, height = 16;

	public static Shape rect = new Rectangle(getPlayershitboxX(),
			getPlayershitboxY(), width, height);

	public static float pdelta;

	public static Animation Playeranime;

	public static void setpdelta(float somenum) {

		pdelta = somenum;

	}

	public static float getpdelta() {

		return pdelta;

	}

	public static float getPlayersX() {

		return x;

	}

	public static float getPlayersY() {

		return y;

	}

	public static float getPlayershitboxX() {

		return x ;

	}

	public static float getPlayershitboxY() {

		return y ;

	}

	public static void setPlayershitboxX() {

		hitboxX = getPlayershitboxX();

	}

	public static void setPlayershitboxY() {

		hitboxY = getPlayershitboxY() -50 ;

	}

}
 

